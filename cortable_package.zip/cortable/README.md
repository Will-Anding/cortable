# cortable — Custom Stata Correlation Table Package

Exports a pairwise correlation table to a Word (.rtf) file with:
- **Lower triangle only**
- **Bold coefficients** at a user-specified significance level
- **Numbered variables** with a legend below the table
- **Configurable decimal places**

---

## Installation

### Option A: Manual install (recommended)
1. Find your Stata personal ado directory by typing in Stata:
   ```stata
   sysdir
   ```
   Look for the `PERSONAL` path (e.g. `C:\Users\yourname\ado\personal\` on Windows,
   or `~/ado/personal/` on Mac/Linux).

2. Copy `cortable.ado` and `cortable.sthlp` into that folder.

3. In Stata, type:
   ```stata
   discard
   ```
   to refresh Stata's memory of available commands.

### Option B: Install from a folder during a session
```stata
adopath + "C:\path\to\cortable_folder"
```

---

## Syntax

```stata
cortable varlist [if] [in] using filename [, siglevel(#) decimals(#)]
```

### Options

| Option | Description | Default |
|---|---|---|
| `siglevel(#)` | p-value threshold for bolding | 0.05 |
| `decimals(#)` | decimal places shown | 3 |

The `.rtf` extension is added automatically if omitted from the filename.

---

## Examples

```stata
* Basic usage — defaults to p<0.05 bolding, 3 decimal places
sysuse auto, clear
cortable price mpg weight length using "my_cortable"

* Bold at 10% level, 2 decimal places
cortable price mpg weight length using "my_cortable", siglevel(0.10) decimals(2)

* Bold only at 1% level, 4 decimal places, subset of observations
cortable price mpg weight if foreign==0 using "my_cortable", siglevel(0.01) decimals(4)
```

---

## Output

The RTF file contains:
1. A bordered correlation matrix (lower triangle only)
2. Column headers as numbers: **(1), (2), (3)...**
3. Row labels as numbers matching columns
4. Bold coefficients where p ≤ siglevel
5. A **Variable Legend** mapping numbers to variable labels
6. A note stating the significance threshold used

Open the `.rtf` file directly in Microsoft Word.

---

## Notes
- Variable **labels** are used in the legend if defined (`label variable`); otherwise the raw variable name is used.
- `if` and `in` conditions are fully supported.
- Correlations are computed pairwise (equivalent to Stata's `pwcorr`).
